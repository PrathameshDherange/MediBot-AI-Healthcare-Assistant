import json
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Union

import _snowflake
import pandas as pd
import streamlit as st 
from snowflake.snowpark.context import get_active_session
from snowflake.snowpark.exceptions import SnowparkSQLException


st.set_page_config(layout="wide", page_title="Your Medi-Assist 💊🤖") 


AVAILABLE_SEMANTIC_MODELS_PATHS = [
    "PATIENT_MEDICATION_DETAILS.HACKATHON.STAGE/hackathon_patient_details_semantic_model.yaml",
]

API_ENDPOINT = "/api/v2/cortex/analyst/message"
FEEDBACK_API_ENDPOINT = "/api/v2/cortex/analyst/feedback"
API_TIMEOUT = 50000 

session = get_active_session()


if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'active_suggestion' not in st.session_state:
    st.session_state.active_suggestion = None
if 'warnings' not in st.session_state:
    st.session_state.warnings = []
if 'api_error_details' not in st.session_state:
    st.session_state.api_error_details = None
if 'form_submitted' not in st.session_state:
    st.session_state.form_submitted = {}
if 'rerun_triggered' not in st.session_state: 
    st.session_state.rerun_triggered = False


def reset_session_state():
    """Reset all relevant session state elements to their initial values."""
    
    st.session_state.messages = []
    st.session_state.active_suggestion = None
    st.session_state.warnings = []
    st.session_state.api_error_details = None
    st.session_state.form_submitted = {}
    st.session_state.rerun_triggered = False 


@st.cache_data(show_spinner=False) 
def get_query_exec_result(query: str) -> Tuple[Optional[pd.DataFrame], Optional[str]]:
    """
    Executes a given SQL query using Snowpark and returns results as a Pandas DataFrame.
    Caches results to prevent re-execution on every rerun.
    Args:
        query (str): The SQL query string to execute.
    Returns:
        Tuple[Optional[pd.DataFrame], Optional[str]]: A tuple containing the DataFrame
        (or None if error) and an error message string (or None).
    """
    global session
    try:
        df = session.sql(query).to_pandas()
        return df, None
    except SnowparkSQLException as e:
        return None, str(e)

def get_analyst_response(messages: List[Dict]) -> Tuple[Dict, Optional[Dict]]:
    """
    Sends the conversation history to the Cortex Analyst API and processes its response.
    Args:
        messages (List[Dict]): The conversation history as a list of message dictionaries.
    Returns:
        Tuple[Dict, Optional[Dict]]: A tuple containing the parsed API response (dict)
        and an error details dictionary (or None if no error).
    """
    request_body = {
        "messages": messages,
        "semantic_model_file": f"@{st.session_state.selected_semantic_model_path}",
    }
    try:
        resp = _snowflake.send_snow_api_request(
            "POST", API_ENDPOINT, {}, {}, request_body, None, API_TIMEOUT
        )
        parsed_content = json.loads(resp["content"])

        if resp["status"] < 400:
            return parsed_content, None
        else:
            error_details = {
                "response_code": resp['status'],
                "request_id": parsed_content.get('request_id', 'N/A'),
                "error_code": parsed_content.get('error_code', 'N/A'),
                "message": parsed_content.get('message', 'Unknown error from Analyst API.')
            }
            return parsed_content, error_details

    except json.JSONDecodeError as e:
        error_details = {
            "response_code": "JSON_PARSE_ERROR",
            "message": f"Failed to parse API response content: {e}",
            "raw_content": resp.get('content', 'No content received') if 'resp' in locals() else 'No response object received',
        }
        return {}, error_details
    except Exception as e:
        error_details = {
            "response_code": "PYTHON_EXCEPTION",
            "message": f"An unexpected Python error occurred during API request: {e}",
        }
        return {}, error_details

def submit_feedback(request_id: str, positive: bool, feedback_message: str) -> Optional[str]:
    """
    Submits user feedback about a generated SQL query to the Cortex Analyst API.
    Args:
        request_id (str): The ID of the request being rated.
        positive (bool): True if the feedback is positive (👍), False if negative (👎).
        feedback_message (str): Optional text feedback from the user.
    Returns:
        Optional[str]: An error message string if feedback submission fails, otherwise None.
    """
    request_body = {
        "request_id": request_id,
        "positive": positive,
        "feedback_message": feedback_message,
    }
    try:
        resp = _snowflake.send_snow_api_request(
            "POST", FEEDBACK_API_ENDPOINT, {}, {}, request_body, None, API_TIMEOUT
        )
        if resp["status"] == 200:
            return None
        parsed_content = json.loads(resp["content"])
        err_msg = f"""
        🚨 An Analyst API error has occurred during feedback submission 🚨
        * response code: `{resp['status']}`
        * request-id: `{parsed_content.get('request_id', 'N/A')}`
        * error code: `{parsed_content.get('error_code', 'N/A')}`
        Message:
        ```
        {parsed_content.get('message', 'Unknown error from feedback API.')}
        ```
        """
        return err_msg
    except json.JSONDecodeError as e:
        return f"Failed to parse feedback API response: {e}. Raw content: {resp.get('content', 'N/A')}"
    except Exception as e:
        return f"An unexpected error occurred during feedback submission: {e}"


def show_header_and_sidebar():
    """Displays the app's title, introductory text, and sidebar elements."""
    st.title("Your Medi-Assist 💊🤖") 

    with st.sidebar:
        st.header("Configuration & Tools")
        st.selectbox(
            "Choose Your Health Data Model:",
            AVAILABLE_SEMANTIC_MODELS_PATHS,
            format_func=lambda s: s.split("/")[-1].replace("_semantic_model.yaml", "").replace("_", " ").title(), # More readable format
            key="selected_semantic_model_path",

            on_change=lambda: st.session_state.update(
                rerun_triggered=True,
                messages=[], 
                active_suggestion=None, 
                warnings=[], 
                api_error_details=None, 
                form_submitted={}
            ),
            help="Select the specific dataset or health model you want to query. Changing this will clear our current conversation."
        )
        st.divider()
        if st.button("Start New Conversation", use_container_width=True, help="Clears all previous messages and starts a fresh chat with Medi-Bot."):
            reset_session_state()
            st.session_state.rerun_triggered = True 

    if st.session_state.rerun_triggered:
        st.session_state.rerun_triggered = False
        st.rerun()

    st.markdown(
        """
        Hello! I'm Medi-Bot, your personal AI health data assistant.
        **Ask me questions about patient medication details in plain language**, and I'll generate the necessary analysis, run it, and present the insights to you.
        """
    )
    st.info("💡 **Quick Tip:** Type your health-related question below, or ask 'What can I ask about?' for example queries.")


def display_conversation():
    """Iterates through the message history and displays each message in the chat interface."""
    for idx, message in enumerate(st.session_state.messages):
        role = message["role"]
        content = message["content"]

        if role == "user":
            avatar_emoji = "🧑‍⚕️" 
        elif role == "analyst":
            avatar_emoji = "🤖"
        else:
            avatar_emoji = None

        with st.chat_message(role, avatar=avatar_emoji): 
            display_message_content(content, idx, message.get("request_id"))
            

def display_message_content(
    content: List[Dict[str, Union[str, Dict]]],
    message_index: int,
    request_id: Union[str, None] = None,
):
    """
    Displays the various parts of a message's content (text, suggestions, SQL/results).
    Args:
        content (List[Dict]): The list of content items for a message.
        message_index (int): The index of the message in the session history.
        request_id (str, optional): The request ID associated with the message, for feedback.
    """
    for item in content:
        if item["type"] == "text":
            st.markdown(item["text"])
        elif item["type"] == "suggestions":
            st.markdown("Perhaps you'd like to explore:") # Changed suggestion prompt
            cols = st.columns(len(item["suggestions"]))
            for suggestion_index, suggestion in enumerate(item["suggestions"]):
                if cols[suggestion_index].button(
                    suggestion, key=f"suggestion_button_{message_index}_{suggestion_index}"
                ):
                    st.session_state.active_suggestion = suggestion
                    st.session_state.rerun_triggered = True 
        elif item["type"] == "sql":
            display_sql_query_with_results(
                item["statement"], message_index, item.get("confidence"), request_id
            )
        else:
            st.warning(f"⚠️ Medi-Bot encountered an unfamiliar content type: `{item['type']}`. Please report this issue.", icon="⚠️") # More specific warning

def display_sql_query_with_results(
    sql: str, message_index: int, confidence: Optional[Dict], request_id: Optional[str] = None
):
    """
    Displays the SQL query in an expander, executes it, and shows results in tabs (Data/Chart).
    Args:
        sql (str): The SQL query string.
        message_index (int): Index of the message for unique key generation.
        confidence (dict, optional): Confidence details about SQL generation.
        request_id (str, optional): Request ID for feedback.
    """
    with st.expander("📝 **Generated SQL Query**", expanded=False): # Changed expander title
        st.code(sql, language="sql")
        display_sql_confidence_info(confidence)

    with st.expander("Analysis Results", expanded=True): # Changed expander title
        with st.spinner("🚀 Processing your request with Snowflake..."): # Changed spinner message
            df, err_msg = get_query_exec_result(sql)
            if df is None:
                st.error(f"❌ Medi-Bot couldn't execute the generated SQL query.\nError details: `{err_msg}`", icon="❌") # Changed error message
            elif df.empty:
                st.info("🤷‍♀️ The query returned no data. Perhaps try a different question?", icon="🤷‍♀️") # Changed info message
            else:
                data_tab, chart_tab = st.tabs(["Raw Data 📊", "Visual Chart 📈"]) # Changed tab names
                with data_tab:
                    df_display = df.head(100)
                    st.dataframe(df_display, use_container_width=True)
                    if len(df) > 100:
                        st.markdown(f"Displaying the first 100 rows out of **{len(df)}** total records. Full data download available below.") # Changed markdown text
                    
                    csv_data = df.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="Download All Data (CSV)", # Changed button label
                        data=csv_data,
                        file_name=f"medi_bot_results_{message_index}.csv", # Changed file name
                        mime="text/csv",
                        key=f"download_csv_button_{message_index}",
                        help="Click to download the complete query results as a CSV file for further analysis." # Changed help text
                    )
                with chart_tab:
                    display_interactive_charts(df, message_index)

    if request_id:
        display_feedback_section(request_id)


def display_sql_confidence_info(confidence: Optional[Dict]):
    """Displays information about the confidence of the generated SQL query."""
    if confidence is None:
        return
    verified_query_used = confidence.get("verified_query_used")
    with st.popover(
        "✨ **Verified Query Insights**", # Changed popover title
        help="Details about pre-approved, validated queries used to formulate this SQL response.", # Changed popover help
    ):
        if verified_query_used is None:
            st.text("This SQL query was generated without using a pre-verified query from our repository.") # Changed text
            return
        st.text(f"Query Name: {verified_query_used.get('name', 'N/A')}") # Changed label
        st.text(f"Original Question: {verified_query_used.get('question', 'N/A')}") # Changed label
        st.text(f"Verified By: {verified_query_used.get('verified_by', 'N/A')}") # Changed label
        st.text(f"Verification Date: {datetime.fromtimestamp(verified_query_used.get('verified_at', 0))}") # Changed label
        st.text("Verified SQL Statement:") # Changed label
        st.code(verified_query_used.get("sql", "N/A"), language="sql", wrap_lines=True)


def display_interactive_charts(df: pd.DataFrame, message_index: int) -> None:
    """
    Displays a flexible charting interface allowing users to select chart types and axes.
    Args:
        df (pd.DataFrame): The DataFrame containing query results.
        message_index (int): The index of the message for unique widget keys.
    """
    numeric_cols = df.select_dtypes(include=['number', 'float', 'int']).columns.tolist()
    non_numeric_cols = df.select_dtypes(exclude=['number', 'float', 'int', 'datetime64']).columns.tolist()
    datetime_cols = df.select_dtypes(include=['datetime64']).columns.tolist()

    all_potential_x_cols = non_numeric_cols + datetime_cols + numeric_cols

    if len(df.columns) < 2 or not numeric_cols:
        st.info("Charts require at least two columns and at least one numeric column for meaningful visualization. Displaying raw data instead.", icon="ℹ️") # Changed info message
        st.dataframe(df, use_container_width=True)
        return

    col1, col2 = st.columns(2)
    x_col = col1.selectbox(
        "Select X-axis (Category/Time/Numeric)", all_potential_x_cols, # Changed label
        key=f"x_col_select_{message_index}"
    )
    y_col = col2.selectbox(
        "Select Y-axis (Numeric Value)", numeric_cols, # Changed label
        key=f"y_col_select_{message_index}"
    )
    
    if x_col and y_col:
        chart_type = st.selectbox(
            "Choose Chart Type", # Changed label
            options=["Bar Chart 📊", "Line Chart 📈", "Area Chart 📈", "Scatter Plot ⚪"],
            key=f"chart_type_select_{message_index}",
        )

        try:
            if chart_type == "Line Chart 📈":
                st.line_chart(df.set_index(x_col)[y_col])
            elif chart_type == "Bar Chart 📊":
                st.bar_chart(df.set_index(x_col)[y_col])
            elif chart_type == "Area Chart 📈":
                st.area_chart(df.set_index(x_col)[y_col])
            elif chart_type == "Scatter Plot ⚪":
                st.scatter_chart(df, x=x_col, y=y_col)

        except Exception as e:
            st.error(f" Medi-Bot couldn't generate the selected chart. Please ensure your column selections are suitable for the chosen chart type. Error: {e}", icon="⚠️") # Changed error message
            st.dataframe(df, use_container_width=True)
    else:
        st.info("Please select both X and Y axis columns to generate a chart visualization.", icon="ℹ️") # Changed info message
        st.dataframe(df, use_container_width=True)


def display_feedback_section(request_id: str):
    """Displays the feedback popover for SQL query rating."""
    with st.popover("⭐ **Rate Medi-Bot's Response**", help="Help us improve Medi-Bot by providing feedback on the generated SQL query and results."): # Changed popover title and help
        submission_status = st.session_state.form_submitted.get(request_id, {}).get("submitted_status", False)
        error_on_submit = st.session_state.form_submitted.get(request_id, {}).get("error", None)

        if not submission_status:
            with st.form(key=f"feedback_form_{request_id}", clear_on_submit=True):
                positive = st.radio(
                    "Was this SQL query helpful?", options=["👍 Yes, it was helpful", "👎 No, it was not helpful"], horizontal=True, key=f"feedback_radio_{request_id}" # Changed radio options
                )
                positive = (positive == "👍 Yes, it was helpful")
                
                feedback_message = st.text_input("Optional comments or suggestions:", key=f"feedback_text_{request_id}") # Changed text input label
                submitted = st.form_submit_button("Submit Feedback to Medi-Bot") # Changed button label
                
                if submitted:
                    current_err_msg = submit_feedback(request_id, positive, feedback_message)
                    st.session_state.form_submitted[request_id] = {"submitted_status": True, "error": current_err_msg}
        elif error_on_submit is None:
            st.success("✅ Thank you for your valuable feedback! We appreciate it.", icon="✅") # Changed success message
        else:
            st.error(f"🚫 An issue occurred while submitting feedback: {error_on_submit}. Please try again later.", icon="🚫") # Changed error message


def handle_user_inputs():
    """Manages user input from chat_input and suggestion buttons."""
    user_input = st.chat_input("Ask Medi-Bot a question about health data...") # Changed chat input placeholder
    
    if user_input:
        process_user_input_and_rerun(user_input)
    elif st.session_state.active_suggestion is not None:
        suggestion = st.session_state.active_suggestion
        st.session_state.active_suggestion = None
        process_user_input_and_rerun(suggestion)


def process_user_input_and_rerun(prompt: str):
    """Processes user prompt, updates history, gets analyst response, and prepares for rerun."""
    st.session_state.warnings = []
    st.session_state.api_error_details = None

    st.session_state.messages.append({
        "role": "user",
        "content": [{"type": "text", "text": prompt}],
    })

    with st.chat_message("analyst"):
        with st.spinner("🔍 Medi-Bot is analyzing your request and preparing a response..."): # Changed spinner message
            response, error_details = get_analyst_response(st.session_state.messages)

            if error_details is None:
                analyst_message_content = response["message"]["content"]
            else:
                analyst_message_content = [{"type": "text", "text": "I apologize, but Medi-Bot encountered an internal issue and couldn't process that request. Please try rephrasing your question or refer to the detailed error information below."}] # Changed error message
                st.session_state.api_error_details = error_details

            st.session_state.messages.append({
                "role": "analyst",
                "content": analyst_message_content,
                "request_id": response.get("request_id", "N/A"),
            })

            if "warnings" in response:
                st.session_state.warnings = response["warnings"]

    st.rerun()


def handle_error_notifications():
    """Displays a detailed notification if an API error has occurred."""
    if st.session_state.get("api_error_details"):
        error_details = st.session_state["api_error_details"]
        st.error(
            f"🚨 **Medi-Bot System Alert** 🚨 (Code: `{error_details.get('response_code', 'N/A')}`, Request ID: `{error_details.get('request_id', 'N/A')}`) "
            f"An unexpected error occurred. Please review the details.", # Changed error message
            icon="🚨"
        )
        with st.expander("Click to view technical error details"): # Changed expander title
            if error_details.get('message'):
                st.markdown(f"**Error Message:**\n```\n{error_details['message']}\n```")
            if error_details.get('raw_content'):
                st.markdown(f"**Raw API Response Content:**\n```\n{error_details['raw_content']}\n```") # Changed label
            st.json(error_details)
        st.session_state["api_error_details"] = None


def display_warnings():
    """Displays any warnings stored in the session state."""
    warnings = st.session_state.warnings
    for warning in warnings:
        st.warning(f"⚠️ Medi-Bot Warning: {warning.get('message', 'An unknown warning was issued.')}", icon="⚠️") # Changed warning message
    st.session_state.warnings = []


def main():
    """Main function to run the Streamlit application."""
    
    show_header_and_sidebar()


    display_conversation()
    handle_user_inputs()
    handle_error_notifications()
    display_warnings()


if __name__ == "__main__":
    main()
